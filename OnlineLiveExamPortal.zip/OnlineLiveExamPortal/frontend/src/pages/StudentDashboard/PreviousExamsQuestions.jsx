import React from "react";

const PreviousExamQuestions = () => {
  return (
    <React.Fragment>
    <div className="previous-exam-questions">
      <h2>Previous Exam Questions</h2>
      <p>Here you can view previous exam questions...</p>
    </div>
    </React.Fragment>
  );
};

export default PreviousExamQuestions;
