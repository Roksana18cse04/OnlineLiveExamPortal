import React from "react";

const ResultAnalysis = () => {
  return (
    <React.Fragment>
    <div className="result-analysis">
      <h2>Result Analysis</h2>
      <p>View your exam results and performance analysis...</p>
    </div>
    </React.Fragment>
  );
};

export default ResultAnalysis;
