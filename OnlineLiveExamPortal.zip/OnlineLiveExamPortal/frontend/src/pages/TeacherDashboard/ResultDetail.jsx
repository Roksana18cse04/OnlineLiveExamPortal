import React from "react";

const Result = () => {
  return(
    <React.Fragment>
         <div><h3>Result Management</h3></div>
    </React.Fragment>
  );
};

export default Result;
