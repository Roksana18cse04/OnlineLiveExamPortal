const API_BASE_URL = "http://localhost:5000"; // Change to your backend URL in production
export default API_BASE_URL;
